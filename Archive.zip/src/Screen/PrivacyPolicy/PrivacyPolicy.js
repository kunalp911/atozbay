import React from "react";
import Header from "../../Component/Header/Header";
import Footer from "../../Component/Footer/Footer";

const PrivacyPolicy = () => {
  return (
    <div>
      <Header />
      <div className="container mt-3"> 
        <h4>Privacy Policy</h4>
      <h1 className='text-center'>comming soon</h1>
      </div>
      <Footer />
    </div>
  );
};

export default PrivacyPolicy;
